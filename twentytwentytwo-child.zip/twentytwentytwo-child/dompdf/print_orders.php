<?php
require_once("../../../../wp-load.php");
require 'vendor/autoload.php';
$order_id = $_GET['id'];
$order = wc_get_order( $order_id );

use Dompdf\Dompdf;
$dompdf = new Dompdf();
$html = '<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="invoice-title">
                <h2>Invoice</h2><h3 class="pull-right">Order # '.$order_id.'(Status: '.$order->status.')</h3>
            </div>
            <hr>
            <div class="row">
                <div class="col-xs-6" style="margin-bottom:30px;">
                    <address>
                    <strong>Billing Address:</strong><br>
                        '.$order->billing_first_name.' '.$order->billing_last_name.' <br>
                        '.$order->billing_email.'<br>
                        '.$order->billing_phone.' <br>
                        '.$order->billing_city.', '.$order->billing_state.'<br>
                        '.$order->billing_postcode.', '.$order->billing_country.'
                    </address>
                </div>
                <div class="col-xs-6 text-right" style="margin-bottom:30px;">
                    <address>
                    <strong>Shipping Address:</strong><br>
                        '.$order->shipping_first_name.' '.$order->shipping_last_name.' <br>
                        '.$order->shipping_phone.' <br>
                        '.$order->shipping_city.', '.$order->shipping_state.'<br>
                        '.$order->shipping_postcode.', '.$shipping->billing_country.'
                    </address>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-6" style="margin-bottom:30px;">
                    <address>
                        <strong>Payment Method:</strong>
                        '.$order->payment_method.'<br>
                    </address>
                </div>
                <div class="col-xs-6 text-right">
                    <address>
                        <strong>Order Date:</strong>
                        '.$order->date_created.'<br><br>
                    </address>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><strong>Order summary</strong></h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-condensed">
                            <thead>
                                <tr>
                                    <td><strong>Item</strong></td>
                                    <td class="text-center"><strong>Price</strong></td>
                                    <td class="text-center"><strong>Quantity</strong></td>
                                    <td class="text-right"><strong>Totals</strong></td>
                                </tr>
                            </thead>
                            <tbody>';
                            $currency_symbol = get_woocommerce_currency_symbol( get_woocommerce_currency() );
                            foreach ( $order->get_items() as $item_id => $item ) {
                               $product = $item->get_product();
                               $product_name = $item->get_name();
                               $product_price = $product->get_price();
                               $quantity = $item->get_quantity();
                               $subtotal = $item->get_subtotal();
                               $total = $item->get_total();

                            $html .= '<tr>
                                    <td>'.$product_name.'</td>
                                    <td class="text-center">'.$currency_symbol.$product_price.'</td>
                                    <td class="text-center">'.$quantity.'</td>
                                    <td class="text-right">'.$currency_symbol.$total.'</td>
                                </tr>';
                            }
                            $html .= '
                                <tr>
                                    <td class="thick-line"></td>
                                    <td class="thick-line"></td>
                                    <td class="thick-line text-center"><strong>Subtotal</strong></td>
                                    <td class="thick-line text-right">'.$currency_symbol.$order->subtotal.'</td>
                                </tr>
                                <tr>
                                    <td class="no-line"></td>
                                    <td class="no-line"></td>
                                    <td class="no-line text-center"><strong>Shipping</strong></td>
                                    <td class="no-line text-right">'.$currency_symbol.$order->shipping_total.'</td>
                                </tr>
                                <tr>
                                    <td class="no-line"></td>
                                    <td class="no-line"></td>
                                    <td class="no-line text-center"><strong>Total</strong></td>
                                    <td class="no-line text-right">'.$currency_symbol.$order->total.'</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>';
$dompdf->loadHtml($html);

$dompdf->setPaper('A4', 'landscape');

$dompdf->render();

$dompdf->stream('orderno_'.$order_id.'.pdf');
?>