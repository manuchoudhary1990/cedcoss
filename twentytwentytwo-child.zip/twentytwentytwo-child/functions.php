<?php
/* enqueue scripts and style from parent theme */
   
function twentytwentytwo_styles() {
	wp_enqueue_style( 'child-style', get_stylesheet_uri(),
	array( 'twenty-twenty-two-style' ), wp_get_theme()->get('Version') );
}
add_action( 'wp_enqueue_scripts', 'twentytwentytwo_styles');


add_filter( 'manage_edit-shop_order_columns', 'add_new_order_admin_list_column' );
function add_new_order_admin_list_column( $columns ) {
    $columns['print_order'] = 'Print Order';
    return $columns;
}
 
add_action( 'manage_shop_order_posts_custom_column', 'add_new_order_admin_list_column_content' );
function add_new_order_admin_list_column_content( $column ) {
    global $post;
    if ( 'print_order' === $column ) {
        $order = wc_get_order( $post->ID );
        echo '<a href="'.site_url().'/wp-content/themes/twentytwentytwo-child/dompdf/print_orders.php?id='.$order->get_id().'" class="wc-print-button" style="padding: 5px 10px; border: 1px solid #5341b1; background: #573de5; color: #fff;">Print order</a>';
    }
}